package com.capgemini.servelets.service;

import java.util.List;

import com.capgemini.servelets.dao.EmployeeDAO;
import com.capgemini.servelets.dao.EmployeeDAOImpl;
import com.capgemini.servelets.dto.EmployeeBean;

public class EmployeeServiceImple implements EmployeeService {

	EmployeeDAO dao=new EmployeeDAOImpl();


	public boolean addEmployee(EmployeeBean bean) {
		// TODO Auto-generated method stub
		return dao.addEmployee(bean);
	}

	public boolean updateEmployee(EmployeeBean bean) {
		// TODO Auto-generated method stub
		return dao.updateEmployee(bean);
	}

	public boolean deleteEmployee(int Id) {
		// TODO Auto-generated method stub
		return dao.deleteEmployee(Id);
	}

	public List<EmployeeBean> getAllEmployeeDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	public EmployeeBean authenticate(int empId, String password) {
		// TODO Auto-generated method stub
		return dao.authenticate(empId, password);
	}

	@Override
	public EmployeeBean searchEmployeeById(int Id) {
		// TODO Auto-generated method stub
		return dao.searchEmployeeById(Id);
	}

}
